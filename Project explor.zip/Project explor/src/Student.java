import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.util.Scanner;

public class Student {
   private String name;
   private String id;
 private    String password;
     private double cgpa;
Scanner scanner=new Scanner(System.in);
    public  void add_student(){
        System.out.println("Enter student name ");
name=scanner.nextLine();
        System.out.println("Enter student id");
 id=scanner.nextLine();
        System.out.println("Enter student cgpa");
 cgpa=scanner.nextDouble();
 scanner.nextLine();
        System.out.println("Enter student password");

 password=scanner.nextLine();
        String line = id + ", " + name + " ," +  cgpa +","+password+"\n";
       write(line);
    }

    public static void write(String line) {
        try {
            RandomAccessFile raf = new RandomAccessFile("student.txt", "rw");
            raf.seek(raf.length());
            raf.writeBytes(line);
            System.out.println("save student information sucessfully ");
            //.out.println(raf.getFilePointer());
        } catch (FileNotFoundException ex) {
            System.out.println("failed to open file");
            ex.printStackTrace();
        } catch (IOException ex) {
            System.out.println("faid to write");
            ex.printStackTrace();

        }
    }
}
